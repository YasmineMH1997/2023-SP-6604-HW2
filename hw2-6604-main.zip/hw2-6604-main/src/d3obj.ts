import * as d3 from 'd3'

export function ForceGraph({
    nodes, // an iterable of node objects (typically [{id}, …])
    links // an iterable of link objects (typically [{source, target}, …])
  }, {
    nodeId = d => d.id, // given d in nodes, returns a unique identifier (string)
    nodeGroup, // given d in nodes, returns an (ordinal) value for color
    nodeGroups, // an array of ordinal values representing the node groups
    nodeTitle = d => d.id, // given d in nodes, a title string
    nodeFill = "currentColor", // node stroke fill (if not using a group color encoding)
    nodeStroke = "#fff", // node stroke color
    nodeStrokeWidth = 1.5, // node stroke width, in pixels
    nodeStrokeOpacity = 1, // node stroke opacity
    nodeRadius = 5, // node radius, in pixels
    nodeStrength,
    linkSource = ({source}) => source, // given d in links, returns a node identifier string
    linkTarget = ({target}) => target, // given d in links, returns a node identifier string
    linkDistance = ({distance}) => distance,
    linkStroke =  "#999",
    linkStrokeOpacity = 0.6, // link stroke opacity
    linkStrokeWidth = 1.5, // given d in links, returns a stroke width in pixels
    linkStrokeLinecap = "round", // link stroke linecap
    linkStrength,
    colors = d3.schemeTableau10, // an array of color strings, for the node groups
    width = 640, // outer width, in pixels
    height = 400, // outer height, in pixels
    invalidation // when this promise resolves, stop the simulation
  } = {},extra=[],greenLinks=[]) {

    console.log("greeeeeeen" , greenLinks)
    const N = d3.map(nodes, nodeId).map(intern);
    const LS = d3.map(links, linkSource).map(intern);
    const LT = d3.map(links, linkTarget).map(intern);
    const LD = d3.map(links,linkDistance).map(intern);

    if (nodeTitle === undefined) nodeTitle = (_, i) => N[i];
    const T = nodeTitle == null ? null : d3.map(nodes, nodeTitle);
    const G = nodeGroup == null ? null : d3.map(nodes, nodeGroup).map(intern);
    const W = typeof linkStrokeWidth !== "function" ? null : d3.map(links, linkStrokeWidth);
    const L = typeof linkStroke !== "function" ? null : d3.map(links, linkStroke);
  
    // Replace the input nodes and links with mutable objects for the simulation.
    nodes = d3.map(nodes, (_, i) => ({id: N[i]}));
    links = d3.map(links, (_, i) => ({source: LS[i], target: LT[i], distance: LD[i]}));
  
    // Compute default domains.
    if (G && nodeGroups === undefined) nodeGroups = d3.sort(G);
  
    // Construct the scales.
    const color = nodeGroup == null ? null : d3.scaleOrdinal(nodeGroups, colors);
  

    var weightScale = d3.scaleLinear()
    .domain(d3.extent(links, function (d) { return d.weight }))
    .range([.1, 1])
    
    // Construct the forces.
    const forceNode = d3.forceManyBody();
    const forceLink = d3.forceLink(links).id(({index: i}) => N[i]).distance((d) => d.distance)
    //.strength(function (d) {return weightScale(d.weight)})
    
    ;//.distance(function(d){console.log(d);return d.distance;});
    if (nodeStrength !== undefined) forceNode.strength(nodeStrength);
    if (linkStrength !== undefined) forceLink.strength(linkStrength);
  
    const simulation = d3.forceSimulation(nodes)
        .force("link", forceLink)
        .force("charge", forceNode)
        .force("center",  d3.forceCenter())
        .on("tick", ticked);
  
    const svg = d3.create("svg")
        .attr("width", width)
        .attr("height", height)
        .attr("viewBox", [-width / 2, -height / 2, width, height])
        .attr("style", "max-width: 100%; height: auto; height: intrinsic;");
  
   /* const link = svg.append("g")
        .attr("stroke", typeof linkStroke !== "function" ? linkStroke : null)
        .attr("stroke-opacity", linkStrokeOpacity)
        .attr("stroke-width", typeof linkStrokeWidth !== "function" ? linkStrokeWidth : null)
        .attr("stroke-linecap", linkStrokeLinecap)
      .selectAll("line")
      .data(links)
      .join("line");*/

      const link = svg.append("g")
    .attr("stroke", typeof linkStroke !== "function" ? linkStroke : null)
    .attr("stroke-opacity", linkStrokeOpacity)
    .attr("stroke-width", typeof linkStrokeWidth !== "function" ? linkStrokeWidth : null)
    .attr("stroke-linecap", linkStrokeLinecap)
  .selectAll("line")
  .data(links)
  .join("line")
  .attr("stroke", d => {
    if (greenLinks.some(link => link.source === d.source.id && link.target === d.target.id/5)) {
      // console.log("red")
         return "green";
       }
 else  if (extra.some(extraLink => extraLink.source === d.source.id && extraLink.target === d.target.id/5)) {
   // console.log("red")
      return "red";
    }
    else {
    //  console.log("black")
      return "#999"}
       // return typeof linkStroke !== "function" ? linkStroke : null;
    //  }
    }).attr("stroke-width", d => {
      if (extra.some(extraLink => extraLink.source === d.source.id && extraLink.target === d.target.id/5)) {
        return 3; // set the stroke width to 3 when the condition is met
      }
      else {
        return 1; // set the default stroke width to 1
      }
    })
    .attr("stroke-width", d => {
      if (extra.some(extraLink => extraLink.source === d.source.id && extraLink.target === d.target.id/5)) {
        return 3; // set the stroke width to 3 when the condition is met
      }
      else {
        return 1; // set the default stroke width to 1
      }
    });


  
    // const node = svg.append("g")
    //     .attr("fill", nodeFill)
    //     .attr("stroke", nodeStroke)
    //     .attr("stroke-opacity", nodeStrokeOpacity)
    //     .attr("stroke-width", nodeStrokeWidth)
    //   .selectAll("circle")
    //   .data(nodes)
    //   .join("circle")
    //     .attr("r", nodeRadius)
    //     .call(drag(simulation));

        // node.append("text")
        // .text(function(d) {
        //   return d.id;
        // })
        // .style('fill', '#000')
        // .style('font-size', '12px')
        // .attr('x', 6)
        // .attr('y', 3);
  
        var node1 = svg.append("g")
      .attr("class", "nodesDat")
    .selectAll("g")
    .data(nodes)
    .enter().append("g")


    var labels = node1
    .append("text")
    .text(function(d) { 
        return parseInt(d.id)%5 === 0 ? `MSS-${parseInt(d.id)/5}` : `MH-${d.id}`;
    })
    .attr("class", "large")
    .call(drag(simulation))


    var node = node1
        .append("circle")
        .data(nodes)
        .attr("r", d => {
          console.log("dd",d)
          if (greenLinks.some(link => link.source === d.id )) {
            // console.log("red")
               return 5;
             }
         else if (extra.some(link => link.source === d.id )) {
            // console.log("red")
               return 8;
             }
             else
          return nodeRadius

        })
        .attr("fill", "#000")//function(d) { return color(d.group); })
        .style("fill", nodeFill)
        .attr("stroke", nodeStroke)
        .attr("stroke-opacity", nodeStrokeOpacity)
        .attr("stroke-width", nodeStrokeWidth)
        .on("mouseenter", (evt, d) => {
            link
              .attr("display", "none")
              .filter(l => l.source.id === d.id || l.target.id === d.id)
              .attr("display", "block");
          })
          .on("mouseleave", evt => {
            link.attr("display", "block");
          })
        .call(drag(simulation))

    if (W) link.attr("stroke-width", ({index: i}) => W[i]);
    if (L) link.attr("stroke", ({index: i}) => L[i]);
    if (G) node.attr("fill", ({index: i}) => color(G[i]));
    //if (T) node.append("title").text(({index: i}) => T[i]);
    if (T) node.append("text").text(({index: i}) => T[i]);
    if (invalidation != null) invalidation.then(() => simulation.stop());
  
    function intern(value) {
      return value !== null && typeof value === "object" ? value.valueOf() : value;
    }
  
    function ticked() {
      link
        .attr("x1", d => d.source.x)
        .attr("y1", d => d.source.y)
        .attr("x2", d => d.target.x)
        .attr("y2", d => d.target.y);
  
      node
        .attr("cx", d => d.x)
        .attr("cy", d => d.y);

        labels
        .attr("x", d=> d.x)
        .attr("y", d=> d.y)
    }
  
    function drag(simulation) {    
      function dragstarted(event) {
        if (!event.active) simulation.alphaTarget(0.3).restart();
        event.subject.fx = event.subject.x;
        event.subject.fy = event.subject.y;
      }
      
      function dragged(event) {
        event.subject.fx = event.x;
        event.subject.fy = event.y;
      }
      
      function dragended(event) {
        if (!event.active) simulation.alphaTarget(0);
        event.subject.fx = null;
        event.subject.fy = null;
      }
      
      return d3.drag()
        .on("start", dragstarted)
        .on("drag", dragged)
        .on("end", dragended);
    }
  
    return Object.assign(svg.node(), {scales: {color}});
  }





/////////

// import * as d3 from 'd3'
// import './App.css';
// // Copyright 2021 Observable, Inc.
// // Released under the ISC license.
// // https://observablehq.com/@d3/force-directed-graph
// export function ForceGraph({
//     nodes, // an iterable of node objects (typically [{id}, …])
//     links // an iterable of link objects (typically [{source, target}, …])
//   }, {
//     nodeId = d => d.id, // given d in nodes, returns a unique identifier (string)
//     nodeGroup, // given d in nodes, returns an (ordinal) value for color
//     nodeGroups, // an array of ordinal values representing the node groups
//     nodeTitle = d => d.id, // given d in nodes, a title string
//     nodeFill = "currentColor", // node stroke fill (if not using a group color encoding)
//     nodeStroke = "#fff", // node stroke color
//     nodeStrokeWidth = 1.5, // node stroke width, in pixels
//     nodeStrokeOpacity = 1, // node stroke opacity
//     nodeRadius = 5, // node radius, in pixels
//     nodeStrength,
//     linkSource = ({source}) => source, // given d in links, returns a node identifier string
//     linkTarget = ({target}) => target, // given d in links, returns a node identifier string
//     linkDistance =({distance}) => distance,
//     linkStroke = "#999", // link stroke color
//     linkStrokeOpacity = 0.6, // link stroke opacity
//     linkStrokeWidth = 1.5, // given d in links, returns a stroke width in pixels
//     linkStrokeLinecap = "round", // link stroke linecap
//     linkStrength,
//     colors = d3.schemeTableau10, // an array of color strings, for the node groups
//     width = 640, // outer width, in pixels
//     height = 400, // outer height, in pixels
//     invalidation // when this promise resolves, stop the simulation
//   } = {} ) {
//     // Compute values.
//     const N = d3.map(nodes, nodeId).map(intern);
//     const LS = d3.map(links, linkSource).map(intern);
//     const LT = d3.map(links, linkTarget).map(intern);
//     const LD = d3.map(links, linkDistance).map(intern);
//     if (nodeTitle === undefined) nodeTitle = (_, i) => N[i];
//     // const T = nodeTitle == null ? null : d3.map(nodes, nodeTitle);
//     const G = nodeGroup == null ? null : d3.map(nodes, nodeGroup).map(intern);
//     const W = typeof linkStrokeWidth !== "function" ? null : d3.map(links, linkStrokeWidth);
//     const L = typeof linkStroke !== "function" ? null : d3.map(links, linkStroke);
  
//     // Replace the input nodes and links with mutable objects for the simulation.
//     nodes = d3.map(nodes, (_, i) => ({id: N[i]}));
    
//     links = d3.map(links, (_, i) => ({source: LS[i], target: LT[i], distance: LD[i]}));
  
//     // Compute default domains.
//     if (G && nodeGroups === undefined) nodeGroups = d3.sort(G);
  
//     // Construct the scales.
//     const color = nodeGroup == null ? null : d3.scaleOrdinal(nodeGroups, colors);
  
//     // Construct the forces.
//     const forceNode = d3.forceManyBody();
//     const forceLink = d3.forceLink(links).id(({index: i}) => N[i]).distance(({index:i}) => LD[i]);
//     if (nodeStrength !== undefined) forceNode.strength(nodeStrength);
//     if (linkStrength !== undefined) forceLink.strength(linkStrength);
  
//     const simulation = d3.forceSimulation(nodes)
//         .force("link", forceLink)
//         .force("charge", forceNode)
//         .force("center",  d3.forceCenter())
//         .on("tick", ticked);
  
//     const svg = d3.create("svg")
//         .attr("width", width)
//         .attr("height", height)
//         .attr("viewBox", [-width / 2, -height / 2, width, height])
//         .attr("style", "max-width: 100%; height: auto; height: intrinsic;");
  
//     //const svg =  svgRef    
//     var link = svg.append("g")
//         .attr("stroke", typeof linkStroke !== "function" ? linkStroke : null)
//         .attr("stroke-opacity", linkStrokeOpacity)
//         .attr("stroke-width", typeof linkStrokeWidth !== "function" ? linkStrokeWidth : null)
//         .attr("stroke-linecap", linkStrokeLinecap)
//       .selectAll("line")
//       .data(links)
//       .join("line");

//       var node1 = svg.append("g")
//       .attr("class", "nodesDat")
//     .selectAll("g")
//     .data(nodes)
//     .enter().append("g")
//     // .append("text")
//     //   .text(function(d) {
//     //     return d.id;
//     //   })
//     //   .attr('x', 6)
//     //   .attr('y', 3);
//     // // .append("circle")
//     // //     .attr("r", nodeRadius)
//     // //     .attr("fill", function(d) { return color(d.group); })
//     // //     .call(drag(simulation))
  
//     var lables = node1
//     .append("text")
//     .text(function(d) { 
//         return d.id;
//     })
//     .attr("class", "small")
//     .call(drag(simulation))
    
  

//   var node = node1
//         .append("circle")
//         .data(nodes)
//         .attr("r", nodeRadius)
//         .attr("fill", "#000")//function(d) { return color(d.group); })
//         .style("fill", nodeFill)
//         .attr("stroke", nodeStroke)
//         .attr("stroke-opacity", nodeStrokeOpacity)
//         .attr("stroke-width", nodeStrokeWidth)
//         .on("mouseenter", (evt, d) => {
//             link
//               .attr("display", "none")
//               .filter(l => l.source.id === d.id || l.target.id === d.id)
//               .attr("display", "block");
//           })
//           .on("mouseleave", evt => {
//             link.attr("display", "block");
//           })
//         .call(drag(simulation))

//   // Create a drag handler and append it to the node object instead
// //   var drag_handler = d3.drag()
// //       .on("start", dragstarted)
// //       .on("drag", dragged)
// //       .on("end", dragended);

// //   drag_handler(node);
  
 
    
//     //node.append("title")
//     //.text(function(d) { return d.id; });

//     // node.append("title")
//     //   .text(function(d) { return d.id; });

//     // const node = svg.selectAll("g")
//     //   .data(nodes).enter()
//     //   .append("g");
  
//     // node.append("circle")
//     //   .attr("r", 10)
//     //   .style("fill", nodeFill)
//     //   .attr("stroke", nodeStroke)
//     //   .attr("stroke-opacity", nodeStrokeOpacity)
//     //   .attr("stroke-width", nodeStrokeWidth)
//     //   .attr("r", nodeRadius)
//     //   //.call(force.drag);
  
//     //   node.append("text")
//     //   .attr("x", 12)
//     //   .attr("dy", ".35em")
//     //   .text(function (d) { return d.id; });

//     // const node = svg.append("g")
//     //     .attr("fill", nodeFill)
//     //     .attr("stroke", nodeStroke)
//     //     .attr("stroke-opacity", nodeStrokeOpacity)
//     //     .attr("stroke-width", nodeStrokeWidth)
//     //   .selectAll("circle")
//     //   .data(nodes)
//     //   .join("circle")
//     //   .attr("r", nodeRadius)
//     //   .call(drag(simulation))
    
//     // // const g = svg.append('g').data(nodes).enter()

//     // // const node = g.append("circle").attr("fill", nodeFill)
//     // // .attr("stroke", nodeStroke)
//     // // .attr("stroke-opacity", nodeStrokeOpacity)
//     // // .attr("stroke-width", nodeStrokeWidth)
//     // // .selectAll("circle")
//     // // .data(nodes)
//     // // .attr("r", nodeRadius)
//     // // .call(drag(simulation))

//     // // const texts = node.append("text")
//     // // .selectAll("text")
//     // // .data(nodes)
//     // // .join("text")
//     // // .text(({index: i}) => T[i])

//     // //   node.append("text")
//     // //   .attr("dx", ".10em")
//     // //   .attr("dy", ".10em")
//     // //   .text(({index: i}) => T[i]);;
      
      
//     //   //.join("text")
//     //   // .attr("text", "hello")
    
//     if (W) link.attr("stroke-width", ({index: i}) => W[i]);
//     if (L) link.attr("stroke", ({index: i}) => L[i]);
//     //if (G) node.attr("fill", ({index: i}) => color(G[i]));
//     //if (T) node.join("text").text(({index: i}) => T[i]);
//     //node.append("title")
//     //    .text(function(d) { return d.id; });
//     //node.append("text").text("Amit")
//     if (invalidation != null) invalidation.then(() => simulation.stop());
    

//     // nodes.append("text")
//     // .attr("x", 12)
//     // .attr("dy", ".35em")
//     // .text(function (d) { return d.title; });

//     function intern(value) {
//       return value !== null && typeof value === "object" ? value.valueOf() : value;
//     }
  
//     function ticked() {
      
      
//     // link
//     //     .attr("x1", d => d.source.x)
//     //     .attr("y1", d => d.source.y)
//     //     .attr("x2", d => d.target.x)
//     //     .attr("y2", d => d.target.y);
//     // node
//     //     .attr("cx", d => d.x)
//     //     .attr("cy", d => d.y);
      
//     //   lables
//     //   .attr("x", d=> d.x)
//     //   .attr("y", d=> d.y)

//     }
  
//     function drag(simulation) {    
//       function dragstarted(event) {
//         if (!event.active) simulation.alphaTarget(0.3).restart();
//         event.subject.fx = event.subject.x;
//         event.subject.fy = event.subject.y;
//       }
      
//       function dragged(event) {
//         event.subject.fx = event.x;
//         event.subject.fy = event.y;
//       }
      
//       function dragended(event) {
//         if (!event.active) simulation.alphaTarget(0);
//         event.subject.fx = null;
//         event.subject.fy = null;
//       }
      
//       return d3.drag()
//         .on("start", dragstarted)
//         .on("drag", dragged)
//         .on("end", dragended);
//     }
  
//     // var k = Math.sqrt(nodes.length / (width * height));

//     //svg
//     //.charge(-10 / k)
//     //.gravity(100 * k)

//     //return Object.assign(svg.node(), {scales: {color}});
//     return Object.assign(svg.node(), {
//         update({nodes, links}) {
    
//           // Make a shallow copy to protect against mutation, while
//           // recycling old nodes to preserve position and velocity.
//           const old = new Map(node.data().map(d => [d.id, d]));
//           nodes = nodes.map(d => Object.assign(old.get(d.id) || {}, d));
//           links = links.map(d => Object.assign({}, d));
    
//           simulation.nodes(nodes);
//           simulation.force("link").links(links);
//           simulation.alpha(1).restart();
    
//           node = node
//             .data(nodes, d => d.id)
//             .join(enter => enter.append("circle")
//               .attr("r", 8)
//               .attr("fill", d => color(d.id)));
    
//           link = link
//             //.data(links, d => `${d.source.id}\t${d.target.id}\t${d.value}\t${d.distance}`)
//             .data(links)
//             .join("line");
//         }
//       });
//   }