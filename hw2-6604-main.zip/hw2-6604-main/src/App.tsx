import React, { useEffect, useRef, useState } from 'react';
import './App.css';
import * as d3 from 'd3'
import { ForceGraph } from './d3obj';
import { Button, CircularProgress, TextField } from '@mui/material';
import Immutable from 'immutable';

function App() {
  const mssArray = [1,2,3,4,5,6,7,8]
  const currentSvg = useRef(null);
  const logsRef = useRef('')
for (var a=[],i=1;i<=40;++i) a[i]=i;

// http://stackoverflow.com/questions/962802#962890
function shuffle(array) {
  var tmp, current, top = array.length;
  if(top) while(--top) {
    current = Math.floor(Math.random() * (top + 1));
    tmp = array[current];
    array[current] = array[top];
    array[top] = tmp;
  }
  return array;
}

a = shuffle(a);
//console.log(a)
a = a.map(data => ({id:data}))
var linksArray = []
for (var i = 5; i <= 40; i+=5){
  for (var j = 1; j<=4; j++){
    // console.log(i)
    linksArray.push({source: i-j, target: i, distance: 50})
  }
}

for (var i = 5; i <= 40; i+=5){
  var tgt = 40

  for (var j = 5; j <= 40-i; j+=5){


    linksArray.push({source: i, target: i+j, distance: 200})
  }
}



// build links

  const [mss1, setMss1] =  useState([{},{},{},{}])
  const [nodes, setNodes] =  useState(a)
  const [links, setLinks] =  useState(linksArray)
  const [current, setCurrent] = useState(-1)
  const [queueMap, setQueueMap] = useState(Immutable.Map())
  const [mssNodes, setMssNodes] = useState(nodes.filter(d => parseInt(d.id) % 5 === 0))
  const [queueLinksColor, setQueueLinksColor] = useState("#ff0000"); // red color
  const [logs, setLogs] = useState("")

  const [mss2, setMss2] =  useState([])
  const [mss3, setMss3] =  useState([])
  const [mss4, setMss4] =  useState([])

  function getLocalHosts(n: number): number[] {
    const start = n * 5 -1
    const result: number[] = []
    for (let i = start ; i > n * 5 -5; i--){
      result.push(i)
    }
    return result
  }

  const syncQueues = () => {
    var t = logs
    queueMap.entrySeq().forEach((k,v) => {
        t = t.concat(`Sync MSS ${k[0]/5} with rest\n`) 
        return true
    })
    setLogs(t)
  }

  const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

  const fulfillLocals = (i) => {
    var arrayForMss = queueMap.get(i)
    var templogs = logs
    templogs = templogs.concat(`MSS-${i} fulfilling local MHs\n`)
    //console.log(templogs)
    setLogs(templogs)    
  }

  const fulfillRequest = (i:number = 1) => {
    setCurrent(i)
    const nodesForArray = queueMap.get(i)
    var localNodes = nodesForArray.filter(node => node.mh_id > ((i-1) * 5) && node.mh_id < i * 5)
    console.log(localNodes)
    var tempmap = queueMap
    var tempGreen = [];
    for( var z = 0; z < localNodes.length; z++){
      var templogs = logs
      console.log(`MSS-${i} delivering to MH-${localNodes[z].mh_id}\n`)
      templogs = templogs.concat(`MSS-${i} delivering to MH-${localNodes[z].mh_id}\n`) 
      templogs = templogs.concat(`MSS-${i} release from MH-${localNodes[z].mh_id}\n`) 
      templogs = templogs.concat(`\tMSS-${i} delete MH-${localNodes[z].mh_id} from all others\n`)
      //remove object {source: localNodes[z].mh_id,target:i} from extraLinks
    //  console.log("source",localNodes[z].mh_id)
     // console.log("target",i)

for (var j = 0; j < extraLinks.length; j++) {
  var link = extraLinks[j];
  if (link.source === localNodes[z].mh_id && link.target === i) {
    tempGreen.push(link)
  } 
}
setGreenLinks([...greenLinks, ...tempGreen])

//setExtraLinks(updatedExtraLinks);
   
    //  console.log("Updated Extra Links",updatedExtraLinks)
      for( var t = 1; t <= 8; t++){
        if (t !== i){
          var nodesForT = tempmap.get(t)
          // console.log(nodesForT, 'before')
          nodesForT = nodesForT.filter(mh => mh.mh_id !== localNodes[z].mh_id)
          //  console.log(nodesForT, 'after')
          tempmap = tempmap.set(t, nodesForT)
          templogs = templogs.concat(`\t\tMSS-${t} delete MH-${localNodes[z].mh_id}\n`)
          setLogs(templogs) 
          setQueueMap(tempmap)
        }
      }
      templogs = templogs.concat(`\tMSS-${i} delete MH-${localNodes[z].mh_id}\n`)
      var tempArray = tempmap.get(i)
      tempArray = tempmap.get(i).filter(mh => mh.mh_id !== localNodes[z].mh_id)
      tempmap = tempmap.set(i, tempArray)
      //console.log(localNodes, 'before')
      //const leftOutNodes = nodesForArray.filter(mh => !localNodes.includes(mh))
      //console.log(localNodes, 'after')
      //tempmap = tempmap.set(i, localNodes)
      setQueueMap(tempmap)
      setLogs(templogs) 
    }
    //setCurrent(-1)
    //var arrayForMss = queueMap.get(i)

   //fulfillLocals(i)

  }

  const [extraLinks, setExtraLinks] =  useState([])
  const [greenLinks, setGreenLinks] =  useState([])
  const fillQueue = () => {
    var t = queueMap;
    var links = [];
    var templogs = logs
    mssNodes.forEach((element) => {
      const randomIndex = Math.floor(Math.random() * mssNodes.length);
      const randomMSS = mssNodes[randomIndex].id / 5;
      const localHosts = getLocalHosts(randomMSS);
      const queueForNode = t.get(mssNodes[randomIndex].id) || [];
      let randomLocalMH;
      do {
        randomLocalMH = localHosts[Math.floor(Math.random() * 4)];
      } while (queueForNode.some((item) => item.mh_id === randomLocalMH));
      templogs = templogs.concat(`MSS-${randomMSS} got request from MH-${randomLocalMH}\n`)
      templogs = templogs.concat(`MSS-${randomMSS} is marking MH-${randomLocalMH} as U\n`)

      templogs = templogs.concat("\t Syncing with other MSSs\n")
      const restOfMss = mssArray.filter(t => t !== randomMSS)
      const listOfP:number[] = []
      for(var z =0 ; z < restOfMss.length; z++){
        // console.log(t)
        // console.log(restOfMss[z])
        const maxP = (t.get(restOfMss[z]) || []).length 
        templogs = templogs.concat(`\t\t ${restOfMss[z]} is reporting priority ${maxP}\n`)
        listOfP.push(maxP)
      }
      // console.log(listOfP)
      //templogs = templogs.concat(`\tMSS${element.id} got request from MH ${mh_id}`)
      const entry = {mh_id: randomLocalMH, h_count: 0, priority: Math.max(...listOfP), status: 'D'}
      queueForNode.push(entry);
      // console.log('t before', t)
      //push to rest of MSSs
      for(var u =0 ; u < mssArray.length; u++){
        //t = t.set(mssNodes[z].id, (t.get(mssNodes[z].id) || []).push(entry));
        if(u!== randomMSS){
          const oldarray = (t.get(mssArray[u]) || [])
          oldarray.push(entry)
          t = t.set(mssArray[u], oldarray)
        }
        
      }
      // console.log('t after', t)
      templogs = templogs.concat(`\t MSS-${randomMSS} synced priority for MH-${randomLocalMH} as ${entry.priority}\n`)
      links.push({source: randomLocalMH, target: randomMSS})
      //t = t.set(mssNodes[randomIndex].id, queueForNode);
      //d3.select(`line[data-source="${extraLink.source}"][data-target="${extraLink.target}"]`)
        //.attr('stroke', 'red');
    });
    setLogs(templogs);
    setQueueMap(t);
    setExtraLinks([...extraLinks, ...links])
    console.log("extra links",links)
  };
  
  
  
  useEffect(() => {

    const graph = ForceGraph({ nodes, links },{},extraLinks,greenLinks);

    logsRef.current = logs
    if(currentSvg.current){
      currentSvg.current.innerHTML=""
      currentSvg.current.appendChild(graph)
    } 

  },[nodes, mssNodes, queueMap,extraLinks,logs,logsRef,fillQueue,greenLinks])
  const [value, setValue] = useState("");
  return (
    <div>
      <div style={{height:"100%", width:"100%", padding: "20px"}} id="divid" ref={currentSvg}>
      </div>
      <div>
        <div id="buttonPanel">
          <Button type='button' color='primary' variant='contained' style={{margin:"10px"}}  onClick={(e) => {
    e.preventDefault(); fillQueue(); }}>Generate Ring Requests</Button>
          {/* <Button type='button' color='primary' variant='contained' style={{margin:"10px"}} onClick={() => syncQueues()}>Sync Queues</Button> */}
          <Button type='button' color='primary' variant='contained' style={{margin:"10px"}} onClick={() => fulfillRequest()} disabled>Fulfill Requests</Button>
          <div>
            {
              mssArray.map((mss) => (<Button onClick={() => fulfillRequest(mss)}>{mss}</Button>))
            }
          </div>
        </div>
        <div style={{width: "100%", display:"flex"}} >
          <div  style={{width: "70%"}}>
            <strong>MSS Queues:</strong>
            {
              mssNodes.map((mss) => 
                                  (<div id={mss.id} key={mss.id} style={{width: "70%"}}>
                                            MSS-{parseInt(mss.id)/5} {current === parseInt(mss.id)/5 &&  <CircularProgress/>}
                                            <TextField size='medium' disabled style={{width: "100%"}} value={JSON.stringify(queueMap.get(parseInt(mss.id)/5))}></TextField>
                                    </div>
                                  )
                          )
            }
          </div>
          <div  style={{width: "30%"}}>
            <strong>MSS Logs:</strong>
            <TextField multiline style={{width:"100%"}} disabled minRows={20} value={logs} />
          </div>
        </div>
        
      </div>
    </div>
  );
}

export default App;
